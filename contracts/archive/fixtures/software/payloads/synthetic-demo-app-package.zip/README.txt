Synthetic Demo App package
This archive is a bounded fixture.
