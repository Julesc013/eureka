3Com 3C905 driver package README for Windows 95. Text fixture, not a real driver archive.
