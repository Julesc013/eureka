Creative CT1740 driver package README for Windows 98. Text fixture, not a real driver archive.
