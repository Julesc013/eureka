Legacy hardware driver support bundle fixture for Creative CT1740 Windows 98 and 3Com 3C905 Windows 95 driver evidence.
