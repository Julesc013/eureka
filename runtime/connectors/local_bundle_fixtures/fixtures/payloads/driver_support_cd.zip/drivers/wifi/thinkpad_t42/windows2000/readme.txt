Readme stand-in: ThinkPad T42 wireless driver package shape for Windows 2000. Not a real driver.
