ThinkPad T42 wireless support bundle fixture. Text stand-ins only; no real driver binaries are redistributed.
