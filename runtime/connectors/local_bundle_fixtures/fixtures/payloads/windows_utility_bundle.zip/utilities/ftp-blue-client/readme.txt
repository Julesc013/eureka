Blue FTP client fixture note for Windows XP-era vague identity tests. This is not a real application payload.
