Windows 7 utility bundle fixture. Text stand-ins only; no real executables are redistributed. Includes individual Windows 7 apps and utility installer candidates.
