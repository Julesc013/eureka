Windows 7 utility bundle fixture. Text stand-ins only; no real executables are redistributed.
