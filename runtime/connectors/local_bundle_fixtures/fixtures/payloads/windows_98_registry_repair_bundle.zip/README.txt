Windows 98 registry repair utility bundle fixture. Text stand-ins only; no real executable payload is included.
