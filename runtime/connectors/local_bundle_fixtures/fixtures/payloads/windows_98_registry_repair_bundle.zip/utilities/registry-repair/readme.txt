Registry repair utility README. Intended source-shape evidence for software to fix broken registry on Windows 98. The fixture points to a text stand-in installer member.
