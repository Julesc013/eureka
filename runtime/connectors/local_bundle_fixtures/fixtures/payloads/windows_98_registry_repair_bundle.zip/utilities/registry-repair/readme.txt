Registry repair utility README. Intended source-shape evidence for software to fix broken registry Windows 98.
