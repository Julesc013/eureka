Old blue FTP client for XP readme fixture. Classic Windows file transfer app blue globe clue, documentation only.
