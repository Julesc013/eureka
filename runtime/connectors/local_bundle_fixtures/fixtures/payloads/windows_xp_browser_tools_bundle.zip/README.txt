Windows XP software bundle fixture with XP browser notes and old blue FTP client evidence. Text stand-ins only.
