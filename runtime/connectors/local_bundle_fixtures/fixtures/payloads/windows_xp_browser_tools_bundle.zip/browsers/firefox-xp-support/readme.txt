Firefox XP browser support notes fixture. Mentions Windows XP compatibility evidence and support-window investigation.
