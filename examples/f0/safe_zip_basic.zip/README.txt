F0 safe fixture: manifest-only enumeration sample.
