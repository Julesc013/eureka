Safe member kept beside the blocked traversal member.
