Synthetic fixture with a manifest-like member.
