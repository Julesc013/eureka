Synthetic tar fixture readme.
