Synthetic fixture readme for Tier 0 and Tier 1 listing.
